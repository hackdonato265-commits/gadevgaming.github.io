/*
  CONFIGURACIÓN INICIAL DE JUEGOS
  Los juegos publicados se guardan desde el panel de administración del sitio.
  Si prefieres configurarlos manualmente, agrega objetos a MIS_JUEGOS.
  Los archivos HTML deben estar dentro de htmlgames/.

  Ejemplo:
  {
    nombre: "Mi juego",
    tipo: "html",
    archivo: "mi-juego/index.html", // htmlgames/mi-juego/index.html
    descripcion: "Descripción del juego",
    portada: "portada.png", // dentro de imagenes/ o una URL pública
    plataforma: "HTML5 / Web"
  }
*/
const MIS_JUEGOS = [];
